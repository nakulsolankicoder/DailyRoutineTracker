package com.nakul.dailytracker

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("daily_wins", Context.MODE_PRIVATE) }
    private val tasks = listOf(
        Task("milk", "Breakfast — 1 litre milk", "6:00 AM"),
        Task("study1", "Studies · 2 hours", "6:00–8:00 AM"),
        Task("gym", "Gym workout", "11:00 AM–1:00 PM"),
        Task("lunch", "Lunch — soya chunks + protein shake", "1:00 PM"),
        Task("edit", "Video editing", "1:00–3:00 PM"),
        Task("study2", "Studies · 3 hours", "3:00–6:00 PM"),
        Task("oats", "Protein oats", "6:00 PM"),
        Task("skill", "Learn a new skill", "6:00–8:00 PM"),
        Task("study3", "Studies · 1 hour", "8:00–9:00 PM"),
        Task("dinner", "Dinner, then free time", "9:00 PM")
    )
    private lateinit var root: LinearLayout
    private lateinit var progressText: TextView
    private lateinit var progressBar: TextView
    private lateinit var waterText: TextView
    private val waterButtons = mutableListOf<Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ensureToday()
        buildUi()
        requestNotificationPermissionIfNeeded()
        scheduleDailyAlarms(this)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11, 13, 18)) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(30))
        }
        scroll.addView(root)
        setContentView(scroll)

        text("DAILY ROUTINE · ONE TICK AT A TIME", 12, Color.rgb(181, 244, 119), true)
        text("Daily Wins ⚡", 30, Color.WHITE, true)
        text(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()), 14, Color.LTGRAY, false)
        gap(16)

        card {
            progressText = text("Today's progress: 0 / ${tasks.size + 1}", 17, Color.WHITE, true)
            progressBar = text("□□□□□□□□□□", 19, Color.rgb(181, 244, 119), true)
            text("Study target: 6 hours · Water target: 4 litres", 13, Color.LTGRAY, false)
        }
        gap(12)

        section("🌅 Morning · 6–8 AM") {
            taskRow(tasks[0])
            taskRow(tasks[1])
        }
        section("🏋️ Gym · 11 AM–1 PM") { taskRow(tasks[2]) }
        section("🍛 Lunch + content · 1–3 PM") {
            taskRow(tasks[3])
            taskRow(tasks[4])
        }
        section("📚 Studies · 3–6 PM") { taskRow(tasks[5]) }
        section("🚀 Skills + snack · 6–8 PM") {
            taskRow(tasks[6])
            taskRow(tasks[7])
        }
        section("📖 Night studies · 8–9 PM") { taskRow(tasks[8]) }
        section("🌙 Dinner · 9 PM onwards") { taskRow(tasks[9]) }

        section("💧 Water intake · 4 litres") {
            waterText = text("0 / 4.0 L", 17, Color.rgb(181, 244, 119), true)
            text("Tap one button for each 500 mL serving (8 servings = 4 L).", 13, Color.LTGRAY, false)
            val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until 8) {
                val b = Button(this).apply {
                    text = "${i + 1} · 500mL"
                    textSize = 10f
                    isAllCaps = false
                    setOnClickListener {
                        val key = "water_$i"
                        prefs.edit().putBoolean(key, !prefs.getBoolean(key, false)).apply()
                        updateProgress()
                    }
                }
                waterButtons.add(b)
                val target = if (i < 4) row1 else row2
                target.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(2), dp(4), dp(2), dp(4))
                })
            }
            addView(row1)
            addView(row2)
        }

        section("🔔 Alarm settings") {
            text("Daily alarms ring at 6 AM, 8 AM, 11 AM, 1 PM, 3 PM, 6 PM, 8 PM and 9 PM. Each alarm plays for up to 30 seconds.", 13, Color.LTGRAY, false)
            button("Enable exact alarms") {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val am = getSystemService(AlarmManager::class.java)
                    if (!am.canScheduleExactAlarms()) {
                        try {
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:$packageName")))
                        } catch (_: Exception) {
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                        }
                    } else {
                        scheduleDailyAlarms(this)
                        toast("Daily alarms scheduled")
                    }
                } else {
                    scheduleDailyAlarms(this)
                    toast("Daily alarms scheduled")
                }
            }
            button("Test alarm sound (30 sec)") {
                val i = Intent(this, AlarmSoundService::class.java).setAction(AlarmSoundService.ACTION_START)
                    .putExtra(AlarmSoundService.EXTRA_LABEL, "Test alarm")
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
            button("Stop ringing alarm") {
                startService(Intent(this, AlarmSoundService::class.java).setAction(AlarmSoundService.ACTION_STOP))
            }
            button("Reset today's checklist") {
                AlertDialog.Builder(this).setTitle("Reset today's checklist?")
                    .setMessage("This clears today's ticks and water servings.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Reset") { _, _ ->
                        val editor = prefs.edit()
                        tasks.forEach { editor.remove("task_${it.id}") }
                        for (i in 0 until 8) editor.remove("water_$i")
                        editor.apply()
                        updateProgress()
                    }.show()
            }
        }
        gap(10)
        text("Important: allow notifications and exact alarms in Android settings. Battery-saving restrictions vary by phone. Sound uses the phone's alarm audio channel and cannot exceed the device's volume limit.", 12, Color.LTGRAY, false)
        updateProgress()
    }

    private fun LinearLayout.taskRow(task: Task) {
        val cb = CheckBox(this).apply {
            text = "${task.title}\n${task.time}"
            textSize = 15f
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(181, 244, 119))
            isChecked = prefs.getBoolean("task_${task.id}", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("task_${task.id}", checked).apply()
                updateProgress()
            }
        }
        addView(cb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(2), dp(2), dp(5)) })
    }

    private fun section(title: String, content: LinearLayout.() -> Unit) {
        card {
            text(title, 17, Color.WHITE, true)
            gap(6)
            content()
        }
        gap(10)
    }

    private fun card(content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(21, 26, 37))
        }
        root.addView(box, LinearLayout.LayoutParams(-1, -2))
        box.content()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView {
        val tv = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
        root.addView(tv, LinearLayout.LayoutParams(-1, -2))
        return tv
    }

    private fun LinearLayout.text(value: String, size: Int, color: Int, bold: Boolean): TextView {
        val tv = TextView(this@MainActivity).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
        addView(tv, LinearLayout.LayoutParams(-1, -2))
        return tv
    }

    private fun LinearLayout.gap(height: Int) { addView(View(this@MainActivity), LinearLayout.LayoutParams(1, dp(height))) }
    private fun gap(height: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(height))) }

    private fun LinearLayout.button(label: String, action: () -> Unit) {
        val b = Button(this@MainActivity).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) })
    }

    private fun updateProgress() {
        if (!::progressText.isInitialized) return
        val taskDone = tasks.count { prefs.getBoolean("task_${it.id}", false) }
        val waterDone = (0 until 8).count { prefs.getBoolean("water_$it", false) }
        val allDone = taskDone + if (waterDone == 8) 1 else 0
        val total = tasks.size + 1
        progressText.text = "Today's progress: $allDone / $total"
        val pct = (allDone * 100) / total
        val filled = pct / 10
        progressBar.text = "█".repeat(filled) + "□".repeat(10 - filled) + "  $pct%"
        waterText.text = String.format(Locale.getDefault(), "%.1f / 4.0 L", waterDone * 0.5)
        waterButtons.forEachIndexed { i, button ->
            val checked = prefs.getBoolean("water_$i", false)
            button.setBackgroundColor(if (checked) Color.rgb(181, 244, 119) else Color.rgb(44, 52, 67))
            button.setTextColor(if (checked) Color.rgb(18, 24, 12) else Color.WHITE)
        }
    }

    private fun ensureToday() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val old = prefs.getString("active_day", null)
        if (old != today) {
            val editor = prefs.edit().putString("active_day", today)
            tasks.forEach { editor.remove("task_${it.id}") }
            for (i in 0 until 8) editor.remove("water_$i")
            editor.apply()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    data class Task(val id: String, val title: String, val time: String)

    companion object {
        private val alarms = listOf(
            AlarmSpec(6, 0, "Breakfast + morning studies"),
            AlarmSpec(8, 0, "Morning study session finished"),
            AlarmSpec(11, 0, "Gym time"),
            AlarmSpec(13, 0, "Lunch + video editing"),
            AlarmSpec(15, 0, "Study session"),
            AlarmSpec(18, 0, "Protein oats + learn a new skill"),
            AlarmSpec(20, 0, "Night study session"),
            AlarmSpec(21, 0, "Dinner time")
        )

        fun scheduleDailyAlarms(context: Context) {
            val manager = context.getSystemService(AlarmManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) return
            alarms.forEachIndexed { index, spec ->
                val intent = Intent(context, AlarmReceiver::class.java)
                    .putExtra(AlarmReceiver.EXTRA_LABEL, spec.label)
                val pi = PendingIntent.getBroadcast(
                    context, 400 + index, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, spec.hour)
                    set(Calendar.MINUTE, spec.minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }

    data class AlarmSpec(val hour: Int, val minute: Int, val label: String)
}
