package com.nakul.dailytracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val label = intent.getStringExtra(EXTRA_LABEL) ?: "Routine reminder"
        val service = Intent(context, AlarmSoundService::class.java)
            .setAction(AlarmSoundService.ACTION_START)
            .putExtra(AlarmSoundService.EXTRA_LABEL, label)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        } catch (_: Exception) {
            // Notification / exact-alarm permission or OEM background limits may prevent startup.
        }
        MainActivity.scheduleDailyAlarms(context)
    }

    companion object {
        const val EXTRA_LABEL = "alarm_label"
    }
}
