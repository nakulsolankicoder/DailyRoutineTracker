# Daily Routine Tracker — Android project

This is the **native Android source project** for your Daily Wins routine tracker. It is not a precompiled APK.

## Included
- Daily checklist for the timetable:
  - 6 AM: 1 litre milk + studies until 8 AM
  - 11 AM–1 PM: gym
  - 1–3 PM: soya chunks + protein shake, video editing
  - 3–6 PM: studies
  - 6–8 PM: protein oats + learn a new skill
  - 8–9 PM: studies
  - 9 PM: dinner, then free time
- 4 L water tracker: eight 500 mL servings
- Scheduled alarms at 6 AM, 8 AM, 11 AM, 1 PM, 3 PM, 6 PM, 8 PM and 9 PM
- Alarm sound loops for up to 30 seconds and vibrates; the notification has a Stop action
- Daily checklist clears on the next date
- Re-schedules alarms after device reboot or app update

## Build/install
1. Install **Android Studio** on a computer.
2. Unzip this project and open the `DailyRoutineAndroid` folder in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect your Android phone with USB debugging enabled, or choose **Build > Build APK(s)**.
5. For an APK, Android Studio normally saves it under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your phone and install it. Android may ask you to allow installing unknown apps for the file manager you use.

## Important Android permissions
- Open the app and allow notifications.
- Tap **Enable exact alarms** and allow the app to schedule exact alarms in Android settings.
- On some phones, allow background activity / auto-start and set battery use to unrestricted if alarms are being delayed.
- Make sure alarm/media volume is audible. The app uses the device's default alarm ringtone at full player volume, but it cannot override the phone's hardware volume, Do Not Disturb, or OEM restrictions.
- Android 13+ requires notification permission. Android 12+ may require the special exact-alarm permission.

## Limitations
- This source project was generated but **not compiled or tested on a physical phone here**. You must build it with Android Studio to produce the installable APK.
- Exact alarms can be affected by user permission, battery restrictions, reboot timing, and manufacturer-specific Android behavior.
- The app plays the alarm for 30 seconds; the notification's Stop action silences it sooner.
- Water intake target is a user-selected goal; do not force fluids if a clinician has advised a restriction.
